<nav id='menu'>
  <input type='checkbox' id='responsive-menu' onclick='updatemenu()'><label></label>
  <ul>
    <li><a href='cars.php'>Home</a></li>
    <li><a class='dropdown-arrow' href='cars.php'>Cars</a>
      <ul class='sub-menus'>
        <li><a href='cars.php'>Car List</a></li>
        <li><a href='InsertCar.php'>Add Car</a></li>
      </ul>
    </li>
    <li><a href='messages.php'>Messages</a></li>
    <li><a class='dropdown-arrow' href='testimonials.php'>Testimonials</a>
      <ul class='sub-menus'>
        <li><a href='testimonials.php'>List</a></li>
        <li><a href='InsertTestimonials.php'>Add</a></li>
      </ul>
    </li>
    <li><a href='#'>Contact Us</a></li>
  </ul>
</nav>